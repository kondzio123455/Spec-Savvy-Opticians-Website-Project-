<?php
// Name: Konrad Skoczylas
// ID: C00309030

// Get all letter details from URL
$sale_id = isset($_GET['sale_id']) ? (int)$_GET['sale_id']             : '';
$left    = isset($_GET['left'])    ? htmlspecialchars($_GET['left'])    : '';
$right   = isset($_GET['right'])   ? htmlspecialchars($_GET['right'])   : '';
$lens    = isset($_GET['lens'])    ? htmlspecialchars($_GET['lens'])    : '';
$uv      = isset($_GET['uv'])      ? ((int)$_GET['uv'] ? 'Yes' : 'No') : 'No';
$scratch = isset($_GET['scratch']) ? ((int)$_GET['scratch'] ? 'Yes' : 'No') : 'No';
$date    = date('d/m/Y'); // Today's date
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Lab Letter</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 60px; }
        p { margin: 5px 0; }
        .section { margin-bottom: 20px; }
    </style>
</head>
<body onload="window.print()"> <!-- Auto-opens print dialog -->

<div class="section">
    <p>Specs World,</p>
    <p>Main Street,</p>
    <p>Carlow</p>
</div>

<div class="section">
    <p><?php echo $date; ?></p>
</div>

<div class="section">
    <p>Clear View Lens Laboratory,</p>
    <p>O'Connell Street,</p>
    <p>Dublin 1.</p>
</div>

<div class="section">
    <p>Our Reference: <?php echo $sale_id; ?></p>
</div>

<div class="section">
    <p>Please supply and fit lenses in the enclosed frames, as per the details below:</p>
</div>

<div class="section">
    <p>Left Eye: <?php echo $left; ?></p>
    <p>Right Eye: <?php echo $right; ?></p>
    <p>Lens Material: <?php echo ucfirst($lens); ?></p>
    <p>U-V Filter: <?php echo $uv; ?></p>
    <p>Scratch Coating: <?php echo $scratch; ?></p>
</div>

<div class="section">
    <p>Yours sincerely,</p>
    <br><br>
    <p>________________________,</p>
    <p>Optician.</p>
</div>

</body>
</html>