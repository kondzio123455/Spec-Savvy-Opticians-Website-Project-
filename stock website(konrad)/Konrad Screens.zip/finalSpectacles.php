<?php
// Name: Konrad Skoczylas
// ID: C00309030

include 'db.inc.php'; // Include database connection

// Redirect back if form was not posted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: selectSpectacles.php");
    exit();
}

// Get all posted values from spectaclesDetails.php
$customer_ID  = $_POST['customer_ID'];
$Stock_id     = $_POST['Stock_id'];
$lens_material= $_POST['lens_material'];
$scratch      = $_POST['scratch_resistant'];
$uv           = $_POST['uv_filter'];
$total_cost   = str_replace('€', '', $_POST['total_cost']); // Strip euro sign before storing
$deposit      = str_replace('€', '', $_POST['deposit']);
$balance      = str_replace('€', '', $_POST['balance']);
$sale_date    = date('Y-m-d'); // Use today's date

// Fetch most recent eye test for this customer to store with sale
$stmt0 = mysqli_prepare($con, "SELECT left_lens, right_lens FROM `Eye Test` WHERE customer_ID = ? AND Deleted = 0 ORDER BY date_of_test DESC LIMIT 1");
mysqli_stmt_bind_param($stmt0, "i", $customer_ID);
mysqli_stmt_execute($stmt0);
$eyetest = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt0));
mysqli_stmt_close($stmt0);

$left_lens  = $eyetest['left_lens'];
$right_lens = $eyetest['right_lens'];

// Insert the new sale record into SpectacleSale table
$stmt = mysqli_prepare($con, "
    INSERT INTO SpectacleSale
    (customer_ID, Stock_id, lens_material, scratch_resistant, uv_filter, total_cost, deposit_paid, balance, sale_date)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
");

if (!$stmt) {
    die("Prepare failed: " . mysqli_error($con)); // Stop if prepare fails
}

// Bind all values
mysqli_stmt_bind_param($stmt, "iisisddds",
    $customer_ID, $Stock_id, $lens_material, $scratch, $uv, $total_cost, $deposit, $balance, $sale_date
);

if (mysqli_stmt_execute($stmt)) {
    $sale_id = mysqli_insert_id($con); // Get the auto-assigned sale reference number
    mysqli_stmt_close($stmt);
    mysqli_close($con);
    // Redirect to success page with all data needed for the print letter
    header("Location: selectSpectacles.php?added=" . $sale_id
        . "&sale_id="      . $sale_id
        . "&left="         . urlencode($left_lens)
        . "&right="        . urlencode($right_lens)
        . "&lens="         . urlencode($lens_material)
        . "&uv="           . $uv
        . "&scratch="      . $scratch
    );
    exit();
} else {
    echo "Error: " . mysqli_stmt_error($stmt);
    mysqli_stmt_close($stmt);
}

mysqli_close($con); // Close database connection
?>